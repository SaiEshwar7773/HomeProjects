package com.capgemini.fms.service;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.fms.bean.Feedback;
import com.capgemini.fms.bean.Training;


public interface ICoordinatorService {
	
	
	int addNewProgram(Training program); // Coordinator

	ArrayList<Training> viewAll(); // Coordinator

	int deleteProgram(int trainingCode); // Coordinator

	Training getTrainingProgram(int trainingCode); // Coordinator

	int updateProgram(Training prog); // Coordinator

	boolean checkFaculty(int faculty);//Coordinator
	
	String doLogin(int userId, String password);

	boolean checkParticipant(int partId);

	boolean checkTrainingCode(int trainingCode);

	List<Feedback> getFeedbackbyParticipent(int pId);

	List<String> validatePid(int pId);

	List<String> validateFid(int fId);

	List<Feedback> getFeedbackbyFaculty(int fId);

	List<Integer> getTrainingCodes();

	List<Float> getFeedbackbyTrainingCode(int index);

	
	
}
