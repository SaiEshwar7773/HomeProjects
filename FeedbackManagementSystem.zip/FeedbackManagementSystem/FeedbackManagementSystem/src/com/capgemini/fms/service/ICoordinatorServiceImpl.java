package com.capgemini.fms.service;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.fms.bean.Feedback;
import com.capgemini.fms.bean.Training;
import com.capgemini.fms.dao.ICoordinatorDAO;
import com.capgemini.fms.dao.ICoordinatorDAOImpl;

public class ICoordinatorServiceImpl implements ICoordinatorService {

	ICoordinatorDAO iCDao = new ICoordinatorDAOImpl();

	@Override
	public int addNewProgram(Training program) {// Coordinator
		// TODO Auto-generated method stub
		return iCDao.addNewProgram(program);
	}

	@Override
	public ArrayList<Training> viewAll() {// Coordinator
		// TODO Auto-generated method stub
		return iCDao.viewAll();
	}

	@Override
	public int deleteProgram(int trainingCode) {// Coordinator
		// TODO Auto-generated method stub
		return iCDao.deleteProgram(trainingCode);
	}

	@Override
	public Training getTrainingProgram(int trainingCode) {// Coordinator
		// TODO Auto-generated method stub
		return iCDao.getTrainingProgram(trainingCode);
	}

	@Override
	public int updateProgram(Training prog) {// Coordinator
		// TODO Auto-generated method stub
		return iCDao.updateProgram(prog);
	}

	@Override
	public boolean checkFaculty(int faculty) {
		// TODO Auto-generated method stub
		return iCDao.checkFaculty(faculty);
	}

	@Override
	public String doLogin(int userId, String password) {
		// TODO Auto-generated method stub
		return iCDao.doLogin(userId, password);
	}

	@Override
	public boolean checkParticipant(int partId) { //validation
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean checkTrainingCode(int trainingCode) { //validation
		// TODO Auto-generated method stub
		return false;
	}

	
	
	/*
	FeedBack Methods
	*/
	
	@Override
	public List<Feedback> getFeedbackbyParticipent(int pId) {
		// TODO Auto-generated method stub
		
		return iCDao.getFeedbackbyParticipent(pId);
	}

	@Override
	public List<String> validatePid(int pId) {
		// TODO Auto-generated method stub
		return iCDao.validatePid(pId);
	}

	@Override
	public List<String> validateFid(int fId) {
		// TODO Auto-generated method stub
		return iCDao.validateFid(fId);
	}

	@Override
	public List<Feedback> getFeedbackbyFaculty(int fId) {
		// TODO Auto-generated method stub
		return iCDao.getFeedbackbyFaculty(fId);
	}

	@Override
	public List<Integer> getTrainingCodes() {

		
		return iCDao.getTrainingCodes();
	}

	@Override
	public List<Float> getFeedbackbyTrainingCode(int index) {
		// TODO Auto-generated method stub
		return iCDao.getFeedbackbyTrainingCode(index);
	}

}
