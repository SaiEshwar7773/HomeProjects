package com.capgemini.fms.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.fms.bean.Course;
import com.capgemini.fms.bean.Faculty;
import com.capgemini.fms.bean.Feedback;
import com.capgemini.fms.bean.Training;
import com.capgemini.fms.service.ICoordinatorService;
import com.capgemini.fms.service.ICoordinatorServiceImpl;

import oracle.net.aso.p;

public class Client {

	static Scanner sc = new Scanner(System.in);
	static ICoordinatorService iCService = new ICoordinatorServiceImpl();

	public static void main(String[] args) {

		String role = login();
		System.out.println(role);
		if (role.equalsIgnoreCase("cordinator")) {
			viewCoordinatorPage();

		}
	}

	public static String login() {
		System.out.println("Please enter your Employee ID:");
		int userId = sc.nextInt();
		System.out.println("Please enter your password:");
		String password = sc.next();

		String role = iCService.doLogin(userId, password);
		return role;
	}

	/************
	 * Coordinator Page
	 */
	private static void viewCoordinatorPage() {
		System.out.println("Coordinator Page");

		System.out.println("What do you want to do?");
		System.out.println("1. Training program Maintenance");
		System.out.println("2. Participant Enrollment");
		System.out.println("3. View Feedback Report");

		int option = sc.nextInt();
		switch (option) {
		case 1:
			System.out.println("you are in Training program Maintenance");

			System.out.println("1. Add New PROGRAM");
			System.out.println("2. Update Current PROGRAM");
			System.out.println("3. Delete PROGRAM");
			System.out.println("4. View all Current Programs");
			int key = sc.nextInt();

			switch (key) {
			case 1:
				System.out.println("Add New PROGRAM");

				Training program = new Training();
				System.out.println("Enter Training code");
				program.setTrainingCode(sc.nextInt());
				System.out.println("Enter Course code");
				program.setCourseCode(sc.nextInt());
				System.out.println("Enter Faculty code");
				program.setFacultyCode(sc.nextInt());
				System.out
						.println("Enter program Start date in <YYYY-MM-DD> format");
				program.setStartDate(sc.next());
				System.out.println("Enter end date in <YYYY-MM-DD> format");
				program.setEndDate(sc.next());

				int newProg = iCService.addNewProgram(program);
				if (newProg > 0)
					System.out.println("Client layer " + newProg);

				break;

			case 2:
				System.out
						.println("Please Enter training code for the program to be updated");
				int trainingCode = sc.nextInt();
				Training prog = new Training();
				prog = iCService.getTrainingProgram(trainingCode);

				System.out.println("Enter new faculty code");
				int faculty = sc.nextInt();
				boolean condition = iCService.checkFaculty(faculty);
				if (condition) {
					prog.setFacultyCode(faculty);
					// fmsService.checkFaculty();

					System.out
							.println("Enter new Start Date in <YYYY-MM-DD> format");
					prog.setStartDate(sc.next());

					System.out
							.println("Enter new End Date in <YYYY-MM-DD> format");
					prog.setEndDate(sc.next());

					int up = iCService.updateProgram(prog);
				} else {
					System.out
							.println("ENTERED FACULTY EITHER DOESS NOT EXIST OR HIS ROLE IS NOT FACULTY");
				}
				break;

			case 3:
				System.out.println("Enter training code to be deleted");

				trainingCode = sc.nextInt();

				int status = iCService.deleteProgram(trainingCode);

				if (status > 0)
					System.out.println("Training program Deleated");

				break;
			case 4:
				System.out.println("View all Current Programs");
				ArrayList<Training> trainingArray = new ArrayList<Training>();
				trainingArray = iCService.viewAll();
				trainingArray.forEach(i -> System.out.println(i));
				break;
			default:
				break;
			}

			break;
		case 2:
			System.out.println("you are in Participant Enrollment");
			System.out.println("Enter the participant ID");
			int partId = sc.nextInt();
			boolean check = iCService.checkParticipant(partId);
			if (check) {
				System.out
						.println("Kindly entered the training code to which participant has to be enrolled");
				int trainingCode = sc.nextInt();
				check = iCService.checkTrainingCode(trainingCode);
				if (check) {

				} else {
					System.out.println("Entered Training Code does not exist");
				}
			} else {
				System.out.println("Entered participant ID does not exist");
			}

			break;
		case 3:
			System.out.println("");
			System.out.println("1. View Feedback Report for all Training Programs");
			System.out.println("2. View Feedback Report by Faculty");
			System.out.println("3. View Feedback Report by Participants");

			
			int feedbackOption=0;
			System.out.println("Enter an option");
			feedbackOption=sc.nextInt();
			
			switch (feedbackOption) {
			case 1:
				System.out.println("Report of all training programs");
				
					List<Integer> trainingCodes= iCService.getTrainingCodes();
					List<Float> lFeedBack= new ArrayList<Float>();
					Feedback f1=null;
					List<Integer> noFeedBack = new ArrayList<Integer>();
					 
					for(int i=0; i<trainingCodes.size();i++){
						int index = trainingCodes.get(i);
						lFeedBack=(iCService.getFeedbackbyTrainingCode(index));
						
						lFeedBack.forEach(j-> System.out.println(j));
			for(int j=0; j<lFeedBack.size();j++){
				System.out.println(lFeedBack.get(0)+"  "+lFeedBack.get(1)+" "+lFeedBack.get(2)+" "+lFeedBack.get(3)
						+" "+lFeedBack.get(4));
			}
						System.out.println("/***************************************/");
						
					}
					System.out.print("Traing in codes with no Feedbacks---->");
						
					
					
				break;
				
			case 2:
				System.out.println("Enter Faculty Id");
				
				int fId=sc.nextInt();
				System.out.println("Faculty Id="+fId);
				List<String> facultyRole= new ArrayList<String>();
				facultyRole =iCService.validateFid(fId);
				if(facultyRole!=null){
					if(facultyRole.get(0).equalsIgnoreCase("faculty")){
						List<Feedback> fb =iCService.getFeedbackbyFaculty(fId);
						
					
						System.out.print(facultyRole.get(1)+"--->");
						fb.forEach(i->System.out.println(i));
						
					}
					
					else {
						System.out.println("This ID belongs to ->"+facultyRole.get(0));
						System.out.println("Please Enter faculty ID.");
					}
					}
					else{
						System.out.println("Enter valid faculty ID");
					}
				
				break;
				
				
				
			case 3:
				System.out.println("Inside Report by participant");
				System.out.println("Enter Participent_Id");
				int pId=sc.nextInt();
			
				List<String> participantRole= new ArrayList<String>();
				 participantRole =iCService.validatePid(pId);
					
				if(participantRole!=null){
				if(participantRole.get(0).equalsIgnoreCase("participant")){
					List<Feedback> fb =iCService.getFeedbackbyParticipent(pId);
					
				
					System.out.print(participantRole.get(1)+"--->");
					fb.forEach(i->System.out.println(i));
					
				}
				
				else {
					System.out.println("This ID belongs to ->"+participantRole.get(0));
					System.out.println("Please Enter Particepant ID.");
				}
				}
				else{
					System.out.println("Enter valid Particepant ID");
				}
				break;

			default:
				break;
			}
			
			
			
			break;

		default:
			break;

		}

	}

}
