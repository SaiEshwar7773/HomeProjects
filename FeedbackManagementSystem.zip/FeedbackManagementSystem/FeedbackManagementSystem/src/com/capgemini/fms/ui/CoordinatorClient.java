package com.capgemini.fms.ui;

public class CoordinatorClient {

}
