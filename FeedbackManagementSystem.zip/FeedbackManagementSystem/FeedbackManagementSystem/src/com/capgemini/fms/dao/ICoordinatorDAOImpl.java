package com.capgemini.fms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.fms.bean.Feedback;
import com.capgemini.fms.bean.Training;

public class ICoordinatorDAOImpl implements ICoordinatorDAO {

	Connection conn = DBUtil.getConnection();
	PreparedStatement pstmt;
    
	
	@Override
	public String doLogin(int userId, String password) {
		String role = null;
		try {
			
			System.out.println("Inside   Dao Layer"+userId+" "+password);
			PreparedStatement pstmt = conn
					.prepareStatement(QueryMapper.LOGIN_QUERY);
			pstmt.setInt(1, userId);
			pstmt.setString(2, password);
			ResultSet res = pstmt.executeQuery();
			while(res.next()) {
				role = res.getString(1);
				return role;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return role;
	}
	
	
		
	@Override
	public int addNewProgram(Training program) {
		int insProg = 0;
		try {
			pstmt = conn.prepareStatement(QueryMapper.INSERT_PROGRAM);
			pstmt.setInt(1, program.getTrainingCode());
			pstmt.setInt(2, program.getCourseCode());
			pstmt.setInt(3, program.getFacultyCode());

			Date sDate = java.sql.Date.valueOf(program.getStartDate());
			Date eDate = java.sql.Date.valueOf(program.getEndDate());
			pstmt.setDate(4, sDate);
			pstmt.setDate(5, eDate);

			insProg = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(program.getEndDate());
		return insProg;
	}

	@Override
	public int updateProgram(Training prog) {// Coordinator
		int n = 0;

		try {
			pstmt = conn.prepareStatement(QueryMapper.UPDATE_PROGRAM);
			pstmt.setInt(1, prog.getFacultyCode());
			Date sDate = java.sql.Date.valueOf(prog.getStartDate());
			Date eDate = java.sql.Date.valueOf(prog.getEndDate());
			pstmt.setDate(2, sDate);
			pstmt.setDate(3, eDate);
			pstmt.setInt(4, prog.getTrainingCode());

			n = pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}

		return n;
	}

	@Override
	public Training getTrainingProgram(int trainingCode) {// Coordinator

		try {
			pstmt = conn.prepareStatement(QueryMapper.GET_PROGRAM);
			pstmt.setInt(1, trainingCode);
			ResultSet res1 = pstmt.executeQuery();

			if (res1 == null)
				return null;
			else {
				Training program = new Training();
				while (res1.next()) {
					program.setTrainingCode(trainingCode);
					program.setCourseCode(res1.getInt(2));
					program.setFacultyCode(res1.getInt(3));
					program.setStartDate(String.valueOf(res1.getDate(4)));
					program.setEndDate(String.valueOf(res1.getDate(5)));

				}
				return program;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public ArrayList<Training> viewAll() {// Coordinator

		ArrayList<Training> trainingDao = new ArrayList<Training>();
		Training t1 = new Training();

		try {
			pstmt = conn.prepareStatement(QueryMapper.VIEW_ALL_PROGRAMS);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				t1.setTrainingCode(rs.getInt(1));
				t1.setCourseCode(rs.getInt(2));
				t1.setFacultyCode(rs.getInt(3));
				DateFormat df = new SimpleDateFormat("yyyy/MM/dd");

				String sDate = df.format(rs.getDate(4));
				t1.setStartDate(sDate);
				String endDate = df.format(rs.getDate(5));
				t1.setEndDate(endDate);
				trainingDao.add(t1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return trainingDao;
	}

	@Override
	public int deleteProgram(int trainingCode) {// Coordinator
		int status = 0;
		try {
			pstmt = conn.prepareStatement(QueryMapper.DELETE_PROGRAM);
			pstmt.setInt(1, trainingCode);
			status = pstmt.executeUpdate();
			System.out.println("inside DAO Layer" + status);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return status;
	}

	@Override
	public boolean checkFaculty(int faculty) {// Coordinator
		// TODO Auto-generated method stub
		String role = null;
		try {
			pstmt = conn.prepareStatement(QueryMapper.Valid_QUERY);
			pstmt.setInt(1, faculty);
			ResultSet res = pstmt.executeQuery();
			if (res.next()) {
				role = res.getString(1);
				System.out.println(role);

				if (role.equalsIgnoreCase("faculty"))
					return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}










/*
FeedBack by participant
*/


	@Override
	public List<Feedback> getFeedbackbyParticipent(int pId) {
		
		List<Feedback> listFeedback= new ArrayList<Feedback>();
		Feedback f1=null;
		
		try{
		pstmt = conn.prepareStatement(QueryMapper.FEEDBACK_BY_PARTICI);
		pstmt.setInt(1, pId);
		ResultSet rs= pstmt.executeQuery();
		while(rs.next()){
			f1= new Feedback();
			f1.setTrainingCode(rs.getInt(1));
			f1.setParticipantId(rs.getInt(2));
			f1.setPrsComm(rs.getInt(3));
			f1.setClrfyDbts(rs.getInt(4));
			f1.setTm(rs.getInt(5));
			f1.setHndOut(rs.getInt(6));
			f1.setHwSwNtwrk(rs.getInt(7));
			f1.setComments(rs.getString(8));
			f1.setSuggestions(rs.getString(9));
			listFeedback.add(f1);
			//System.out.println(f1);
		}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		return listFeedback;
	}



	@Override
	public List<String> validatePid(int pId) {
			List<String> l1= null;
			
		try{
		pstmt = conn.prepareStatement(QueryMapper.VALIDATE_PID);
		pstmt.setInt(1, pId);
		ResultSet rs= pstmt.executeQuery();
		while(rs.next()){
			
			l1= new ArrayList<String>();
			l1.add(rs.getString(1));
			l1.add(rs.getString(2));
		
			
		}
		
		return l1;
		}
		catch (Exception e) {
				
			return l1;
		}
		
		
		
	}



	@Override
	public List<String> validateFid(int fId) {

		List<String> l1= null;
		
		try{
		pstmt = conn.prepareStatement(QueryMapper.VALIDATE_FID);
		pstmt.setInt(1, fId);
		ResultSet rs= pstmt.executeQuery();
		while(rs.next()){
			
			l1= new ArrayList<String>();
			l1.add(rs.getString(1));
			l1.add(rs.getString(2));
		
			
		}
		
		return l1;
		}
		catch (Exception e) {
				
			return l1;
		}
		
		
	}



	@Override
	public List<Feedback> getFeedbackbyFaculty(int fId) {
		List<Feedback> listFeedback= new ArrayList<Feedback>();
		Feedback f1=null;
		
		try{
		pstmt = conn.prepareStatement(QueryMapper.FEEDBACK_BY_FACULTY);
		pstmt.setInt(1, fId);
		ResultSet rs= pstmt.executeQuery();
		while(rs.next()){
			f1=new Feedback();
			f1.setTrainingCode(rs.getInt(1));
			f1.setParticipantId(rs.getInt(2));
			f1.setPrsComm(rs.getInt(3));
			f1.setClrfyDbts(rs.getInt(4));
			f1.setTm(rs.getInt(5));
			f1.setHndOut(rs.getInt(6));
			f1.setHwSwNtwrk(rs.getInt(7));
			f1.setComments(rs.getString(8));
			f1.setSuggestions(rs.getString(9));
			listFeedback.add(f1);
			//System.out.println(f1);
		}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		return listFeedback;
	}



	@Override
	public List<Integer> getTrainingCodes() {
		
		List<Integer> tCodes= new ArrayList<Integer>();
		try{
			pstmt = conn.prepareStatement(QueryMapper.GET_TRAINING_CODES);
			
			ResultSet rs= pstmt.executeQuery();
			
			while(rs.next()){
				tCodes.add(rs.getInt(1));
			}
		}
		catch(Exception e){
			
		}
		
		return tCodes;
	}



	@Override
	public List<Float> getFeedbackbyTrainingCode(int index) {
		List<Float> listFeedback= new ArrayList<Float>();
	
		try{
		pstmt = conn.prepareStatement(QueryMapper.FEEDBACK_BY_TRAINING_CODE);
		pstmt.setInt(1, index);
		ResultSet rs= pstmt.executeQuery();
		while(rs.next()){
		
			
			listFeedback.add(rs.getFloat(1));
			listFeedback.add(rs.getFloat(2));
			listFeedback.add(rs.getFloat(3));
			listFeedback.add(rs.getFloat(4));
			listFeedback.add(rs.getFloat(5));
			
		}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		return listFeedback;
	}

}
