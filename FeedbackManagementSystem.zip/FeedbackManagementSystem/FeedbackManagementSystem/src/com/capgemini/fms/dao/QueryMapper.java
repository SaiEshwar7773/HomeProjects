package com.capgemini.fms.dao;

public interface QueryMapper {

	public static final String LOGIN_QUERY = "SELECT e.Role from EMPLOYEE_MASTER e where"
			+ " e.EMPLOYEE_ID = ? AND e.PASSWORD = ?";

	/*
	 * Coordinator Queries
	 */

	public static final String INSERT_PROGRAM = "Insert into TRAINING_PROGRAM values (?,?,?,?,?)";
	
	public static final String VIEW_ALL_PROGRAMS = "select * from Training_Program";
	
	public static final String DELETE_PROGRAM = " Delete from TRAINING_PROGRAM where TRAINING_CODE=?";
	
	public static final String GET_PROGRAM = " Select * from TRAINING_PROGRAM where TRAINING_CODE=?";
	
	public static final String Valid_QUERY = "SELECT e.Role from EMPLOYEE_MASTER e where"
			+ " e.EMPLOYEE_ID = ?";
	
	public static final String UPDATE_PROGRAM = "UPDATE TRAINING_PROGRAM set Faculty_code=?, Start_date=? , End_date=? "
			+ "where Training_code=?";

	public static final String FEEDBACK_BY_PARTICI = "SELECT * FROM FEEDBACK_MASTER where PARTICIPANT_ID =?";

	public static final String VALIDATE_PID = "SELECT ROLE,EMPLOYEE_NAME FROM EMPLOYEE_MASTER  where EMPLOYEE_ID=?";
	
	public static final String VALIDATE_FID = "SELECT ROLE,EMPLOYEE_NAME FROM EMPLOYEE_MASTER  where EMPLOYEE_ID=?";

	public static final String FEEDBACK_BY_FACULTY ="select f.training_code, f.participant_id, f.FB_Prs_comm, f.FB_Clrfy_dbts, "
			+ "													f.FB_TM ,f.FB_Hnd_out ,f.FB_Hw_Sw_Ntwrk, f.comments, f.suggestions"
			+ " 												from feedback_master f join training_program t on t.training_code = f.training_code "
			+ "													join employee_master e on e.employee_id= t.faculty_code "
			+ "													where e.employee_id=?";

	public static final String GET_TRAINING_CODES = "SELECT training_code from training_program" ;

	public static final String FEEDBACK_BY_TRAINING_CODE = "select avg(f.FB_Prs_comm), avg(f.FB_Clrfy_dbts), avg(f.FB_TM) , avg(f.FB_Hnd_out) ,avg(f.FB_Hw_Sw_Ntwrk) "
			+ "from feedback_master f where training_code = ?";
			
}
