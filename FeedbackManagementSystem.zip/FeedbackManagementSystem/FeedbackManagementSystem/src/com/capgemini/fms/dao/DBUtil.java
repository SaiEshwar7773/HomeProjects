package com.capgemini.fms.dao;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.*;
import java.util.Properties;

public class DBUtil {



	public static Connection getConnection()  {
		Connection conn = null;
		FileInputStream fs = null;

		try {
			fs = new FileInputStream(
					"./resources/jdbc.properties");
			Properties prop = new Properties();
			prop.load(fs);
			
			//DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			 Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(prop.getProperty("dburl"),
					prop.getProperty("username"), prop.getProperty("password"));

		
		
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("Inside io exception");
			e.printStackTrace();
		
		}

		catch(Exception e) {
			e.printStackTrace();
			
		}
		return conn;		
		

	}
}
