package com.capgemini.fms.dao;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.fms.bean.Feedback;
import com.capgemini.fms.bean.Training;

public interface ICoordinatorDAO {

	int addNewProgram(Training program); // Coordinator

	ArrayList<Training> viewAll(); // Coordinator

	int deleteProgram(int trainingCode); // Coordinator

	Training getTrainingProgram(int trainingCode); // Coordinator

	int updateProgram(Training prog); // Coordinator

	boolean checkFaculty(int faculty);//Coordinator

	String doLogin(int userId, String password);

	List<Feedback> getFeedbackbyParticipent(int pId);

	List<String> validatePid(int pId);

	List<String> validateFid(int fId);

	List<Feedback> getFeedbackbyFaculty(int fId);

	List<Integer> getTrainingCodes();

	List<Float> getFeedbackbyTrainingCode(int index);
}
