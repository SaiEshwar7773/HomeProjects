package com.capgemini.fms.dao;

public class FeedbackReport {

	public void feedbackByFaculty() {

	}

	public void feedbackByParticipant() {

	}

	public void feedbackByMonth() {

	}

}
